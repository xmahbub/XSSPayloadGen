import sys


listname=str(sys.argv[1])
listfile=str(sys.argv[2])
payloadname=str(sys.argv[3])
payloadfile=str(sys.argv[4])


def Run():
   arq = open(listfile,"r",encoding="utf-8")
   lines = arq.readlines()
   arq.close

   arq1 = open(payloadfile,"r",encoding="utf-8")
   lines1 = arq1.readlines()
   arq1.close


   for url in lines:
      url = url.replace("\n", "")
      for i in lines1:
         final = url.replace("FUZZ",i)
         print(final)
         f= open("success.txt","a")
         f.write(final+'\r')
         f.close()
      
if listname=="-l" and payloadname=="-p":
    z=open("success.txt","w")
    z.close()
    Run()

else:
    print("-l is for domain list")
    print("-p is for Payloads")
    print("Example:")  
    print("python generator.py -l listofdomain.txt -p xsspayloads.txt")
